﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using System.Web.Helpers;

namespace Thumbnail
{
    public class Functions
    {
        public static void Resize(
            [BlobTrigger("images/{name}")] WebImage input,
            [Blob("images-resized/{name}")] out WebImage output)
        {
            var width = 180;
            var height = Convert.ToInt32(input.Height * 180.0 / input.Width);
            output = input.Resize(width, height);
        }
    }
}
