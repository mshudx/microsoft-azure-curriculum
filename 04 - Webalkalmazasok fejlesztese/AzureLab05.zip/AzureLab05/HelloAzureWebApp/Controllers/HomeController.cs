﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloAzureWebApp.Controllers
{
    public class HomeController : Controller
    {
        private static readonly string connectionString = "DefaultEndpointsProtocol=https;AccountName=azuretananyagthumbnail;AccountKey=oRs9ynd2VWSHUyOX6uab15ta4m6XbpFOB8QmacjnW1z0nOi0Jx5rdBx6YzvGe87fwbsH0vLPixaD7FQwLvfh4Q==";
        private static readonly CloudStorageAccount account = CloudStorageAccount.Parse(connectionString);

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file)
        {
            var client = account.CreateCloudBlobClient();
            var container = client.GetContainerReference("images");
            container.CreateIfNotExists();
            container.SetPermissions(new BlobContainerPermissions() { PublicAccess = Microsoft.WindowsAzure.Storage.Blob.BlobContainerPublicAccessType.Off });
            var blob = container.GetBlockBlobReference(file.FileName);
            var bytes = new byte[file.InputStream.Length];
            file.InputStream.Read(bytes, 0, (int)file.InputStream.Length);
            blob.UploadFromByteArray(bytes, 0, bytes.Length);
            return RedirectToAction("Index");
        }
    }
}