﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using TableStorageDemo.Models;

namespace TableStorageDemo
{
    public static class TableRepository
    {
        private static readonly string connectionString = "DefaultEndpointsProtocol=http;AccountName=azuretananyag2;AccountKey=Jz5ZVoy4zu4pU7sO63+WFVoLIOD02faYeF75Sz4KwOJFK1ueUPJ4Ppsx/lLynlRi35x50nanO3J0MCP/8P5+Sg==";
        private static CloudStorageAccount account = CloudStorageAccount.Parse(connectionString);

        private static CloudTable todoTable;

        public static CloudTable TodoTable
        {
            get
            {
                if (todoTable == null)
                {
                    var client = account.CreateCloudTableClient();
                    todoTable = client.GetTableReference("TodoItems");
                    todoTable.CreateIfNotExists();
                }
                return todoTable;
            }
        }
        
        public static IEnumerable<Item> GetIncompleteItems()
        {
            TableQuery<Item> query =
                new TableQuery<Item>().Where(TableQuery.GenerateFilterConditionForBool("Completed",
                    QueryComparisons.Equal, false));
            return TodoTable.ExecuteQuery(query).ToList();
        }

        public static Item CreateItem(Item item)
        {
            item.PartitionKey = DateTime.Today.ToString();
            item.RowKey = Guid.NewGuid().ToString();
            TableOperation insertOperation = TableOperation.Insert(item);
            TodoTable.Execute(insertOperation);
            return item;
        }

        public static Item GetItem(string rowKey)
        {
            TableOperation retrieveOperation = TableOperation.Retrieve<Item>(DateTime.Today.ToString(), rowKey);
            var result = TodoTable.Execute(retrieveOperation);
            return (Item) result.Result;
        }

        public static Item UpdateItem(Item item)
        {
            item.ETag = "*";
            TableOperation updateOperation = TableOperation.Replace(item);
            TodoTable.Execute(updateOperation);
            return item;
        }
    }
}