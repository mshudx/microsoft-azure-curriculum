﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TableStorageDemo.Models;

namespace TableStorageDemo.Controllers
{
    public class ItemController : Controller
    {
        public ActionResult Index()
        {
            var items = TableRepository.GetIncompleteItems();
            return View(items);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Item item)
        {
            if (ModelState.IsValid)
            {
                TableRepository.CreateItem(item);
                return RedirectToAction("Index");
            }

            return View(item);
        }

        public ActionResult Edit(string id)
        {
            Item item = TableRepository.GetItem(id);
            if (item == null)
            {
                return HttpNotFound();
            }
            return View(item);
        }

        [HttpPost]
        public ActionResult Edit(Item item)
        {
            if (ModelState.IsValid)
            {
                TableRepository.UpdateItem(item);
                return RedirectToAction("Index");
            }

            return View(item);
        }
    }
}