﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAzure.Storage.Blob;

namespace BlobDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PopulateContainers()
        {
            lvContainers.Items.Clear();
            List<CloudBlobContainer> containers = CloudManager.GetContainers();
            foreach (var container in containers)
            {
                lvContainers.Items.Add(new ListViewItem {Text = container.Name, Tag = container});
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopulateContainers();
        }

        private void createContainerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string containerName = Prompt.ShowDialog("Container name", "Create container");
            CloudManager.CreateContainer(containerName);
            PopulateContainers();
        }

        private void uploadBlobToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvContainers.SelectedItems.Count != 1) return;

            OpenFileDialog getFileDialog = new OpenFileDialog();
            if (getFileDialog.ShowDialog() == DialogResult.OK)
            {
                CloudManager.UploadBlob(getFileDialog.FileName, (CloudBlobContainer) lvContainers.SelectedItems[0].Tag);
            }
            PopulateBlobs();
        }

        private void PopulateBlobs()
        {
            lvBlobs.Items.Clear();
            if (lvContainers.SelectedItems.Count != 0)
            {
                var blobs = CloudManager.GetBlobs((CloudBlobContainer) lvContainers.SelectedItems[0].Tag);
                foreach (var blob in blobs)
                {
                    lvBlobs.Items.Add(new ListViewItem {Text = blob.Uri.ToString(), Tag = blob.Uri});
                }
            }
        }

        private void lvContainers_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateBlobs();
        }

        private void lvBlobs_DoubleClick(object sender, EventArgs e)
        {
            if (lvBlobs.SelectedItems.Count != 1) return;

            var selectedItem = lvBlobs.SelectedItems[0];
            var uri = (Uri)selectedItem.Tag;
            SaveFileDialog saveFile = new SaveFileDialog()
            {
                FileName = Path.GetFileName(uri.ToString())
            };
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                var contents = CloudManager.DownloadBlob(uri);
                File.WriteAllBytes(saveFile.FileName, contents);
            }
        }
    }
}
