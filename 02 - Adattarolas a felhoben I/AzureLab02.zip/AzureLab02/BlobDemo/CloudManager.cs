﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace BlobDemo
{
    public static class CloudManager
    {
        private static readonly string connectionString = "DefaultEndpointsProtocol=http;AccountName=azuretananyag2;AccountKey=Jz5ZVoy4zu4pU7sO63+WFVoLIOD02faYeF75Sz4KwOJFK1ueUPJ4Ppsx/lLynlRi35x50nanO3J0MCP/8P5+Sg==";
        private static CloudStorageAccount account = CloudStorageAccount.Parse(connectionString);

        public static List<CloudBlobContainer> GetContainers()
        {
            var client = account.CreateCloudBlobClient();
            return client.ListContainers().ToList();
        }

        public static void CreateContainer(string containerName)
        {
            var client = account.CreateCloudBlobClient();
            var container = client.GetContainerReference(containerName);
            container.CreateIfNotExists();
            container.SetPermissions(new BlobContainerPermissions {PublicAccess = BlobContainerPublicAccessType.Off});
        }

        public static void UploadBlob(string file, CloudBlobContainer container)
        {
            var blob = container.GetBlockBlobReference(Path.GetFileName(file));
            blob.UploadFromFile(file);
        }

        public static List<IListBlobItem> GetBlobs(CloudBlobContainer container)
        {
            return container.ListBlobs().ToList();
        }

        public static byte[] DownloadBlob(Uri uri)
        {
            var client = account.CreateCloudBlobClient();
            var blob = client.GetBlobReferenceFromServer(uri);
            blob.FetchAttributes();
            var result = new byte[blob.Properties.Length];
            blob.DownloadToByteArray(result, 0);
            return result;
        }
    }
}
