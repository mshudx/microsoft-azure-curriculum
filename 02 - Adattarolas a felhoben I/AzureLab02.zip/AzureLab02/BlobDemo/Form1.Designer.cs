﻿namespace BlobDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lvContainers = new System.Windows.Forms.ListView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.createContainerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lvBlobs = new System.Windows.Forms.ListView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.uploadBlobToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lvContainers);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lvBlobs);
            this.splitContainer1.Size = new System.Drawing.Size(745, 422);
            this.splitContainer1.SplitterDistance = 248;
            this.splitContainer1.TabIndex = 0;
            // 
            // lvContainers
            // 
            this.lvContainers.ContextMenuStrip = this.contextMenuStrip1;
            this.lvContainers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvContainers.Location = new System.Drawing.Point(0, 0);
            this.lvContainers.Name = "lvContainers";
            this.lvContainers.Size = new System.Drawing.Size(248, 422);
            this.lvContainers.TabIndex = 0;
            this.lvContainers.UseCompatibleStateImageBehavior = false;
            this.lvContainers.View = System.Windows.Forms.View.List;
            this.lvContainers.SelectedIndexChanged += new System.EventHandler(this.lvContainers_SelectedIndexChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createContainerToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(162, 26);
            // 
            // createContainerToolStripMenuItem
            // 
            this.createContainerToolStripMenuItem.Name = "createContainerToolStripMenuItem";
            this.createContainerToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.createContainerToolStripMenuItem.Text = "Create container";
            this.createContainerToolStripMenuItem.Click += new System.EventHandler(this.createContainerToolStripMenuItem_Click);
            // 
            // lvBlobs
            // 
            this.lvBlobs.ContextMenuStrip = this.contextMenuStrip2;
            this.lvBlobs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvBlobs.Location = new System.Drawing.Point(0, 0);
            this.lvBlobs.Name = "lvBlobs";
            this.lvBlobs.Size = new System.Drawing.Size(493, 422);
            this.lvBlobs.TabIndex = 0;
            this.lvBlobs.UseCompatibleStateImageBehavior = false;
            this.lvBlobs.View = System.Windows.Forms.View.List;
            this.lvBlobs.DoubleClick += new System.EventHandler(this.lvBlobs_DoubleClick);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uploadBlobToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(140, 26);
            // 
            // uploadBlobToolStripMenuItem
            // 
            this.uploadBlobToolStripMenuItem.Name = "uploadBlobToolStripMenuItem";
            this.uploadBlobToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.uploadBlobToolStripMenuItem.Text = "Upload blob";
            this.uploadBlobToolStripMenuItem.Click += new System.EventHandler(this.uploadBlobToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 422);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView lvContainers;
        private System.Windows.Forms.ListView lvBlobs;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem createContainerToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem uploadBlobToolStripMenuItem;
    }
}

